'use strict';

describe('projectBoard.team module', function() {

  beforeEach(module('projectBoard.team'));

  describe('team controller', function(){

    it('should ....', inject(function($controller) {
      //spec body
      var teamCtrl = $controller('TeamCtrl');
      expect(teamCtrl).toBeDefined();
    }));

  });
});
